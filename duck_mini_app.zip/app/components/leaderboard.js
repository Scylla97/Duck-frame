export const leaderboard = [
  { address: "0x123...abc", ducks: 121 },
  { address: "0x456...def", ducks: 88 },
  { address: "0x789...ghi", ducks: 55 },
];
