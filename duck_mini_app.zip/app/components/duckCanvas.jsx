export default function DuckCanvas() {
  return (
    <div className="p-4 bg-yellow-100 rounded-xl shadow-lg">
      <img src="/duck.png" alt="Duck" className="w-24 h-24" />
      <p className="mt-2 text-center font-bold">Claim 1 DUCK per second!</p>
    </div>
  );
}
